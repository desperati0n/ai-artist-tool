"""Local archive HTTP service."""
